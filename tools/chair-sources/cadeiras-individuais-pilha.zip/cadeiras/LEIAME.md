# Cadeiras PilhA+ — arquivos individuais

Cada pasta tem o modelo (`.glb`), um ícone com fundo transparente (`_icone.png`, 720×860, para inventário/loja) e uma vista frontal.

| Pasta | Cadeira | Animação (loop) | Peso |
|---|---|---|---|
| cadeira_da_producao | Produção (vermelha) | `subir` | ~1,1 MB |
| cadeira_do_pensamento | Pensamento (amarela) | `digitando` | ~1,1 MB |
| cadeira_da_descompressao | Descompressão (azul) | `pulsar` | ~1,7 MB |

- Unidade: metros. Origem no chão, no centro da base. Frente = +Z (encosto em -Z).
- Marcador de assento: nó `SIT_cadeira_producao` / `SIT_cadeira_pensamento` / `SIT_cadeira_descompressao` (altura ≈ 0,56 m).
- Materiais PBR com verniz (KHR_materials_clearcoat). O `GLTFLoader` do three.js r180 já suporta; não precisa de decoder extra.

## Usar no jogo (three.js)
```js
const gltf = await new GLTFLoader().loadAsync('/assets/cadeiras/cadeira_da_producao.glb');
const cadeira = gltf.scene;
cadeira.position.set(x, 0, z);
scene.add(cadeira);
const mixer = new THREE.AnimationMixer(cadeira);
gltf.animations.forEach(a => mixer.clipAction(a).play());   // no loop: mixer.update(dt)
const assento = cadeira.getObjectByName('SIT_cadeira_producao'); // posição para sentar o personagem
```

## Testar rápido
Dentro desta pasta: `npx serve .` e abra `testar-cadeiras.html` (gira, troca de cadeira e toca a animação).
