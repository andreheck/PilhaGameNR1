# Itens de pátio e sala restaurativa — PilhA+ Game

Modelos 3D procedurais (GLB, three.js r180, unidade = metro, origem na base, Y para cima). Protótipos geométricos, não Meshy.

## Pátio (azul)
| Arquivo | Item |
|---|---|
| banco_wifi_completo.glb | Banco em formato Wi-Fi: 3 arcos + ponto central (~7 m de largura) |
| banco_arco_externo.glb | Arco externo (8 assentos) |
| banco_arco_medio.glb | Arco médio (5 assentos) |
| banco_arco_interno.glb | Arco interno (3 assentos) |
| banco_ponto_central.glb | Ponto central (mesa/pedestal) |

Os arcos têm ~0,35 m de corredor entre si, para os personagens circularem. Cada assento tem um nó vazio `SIT_<arco>_<n>` (posição ≈ altura do quadril sentado, rotação Y já voltada para o centro).
O conjunto abre para +Z: o centro do Wi-Fi fica na origem e os arcos se estendem para -Z.

## Sala restaurativa
| Arquivo | Item | Animação |
|---|---|---|
| tapete_indiano.glb | Tapete indiano estilizado 2,2 × 1,55 m, textura embutida | — |
| caixa_de_som.glb | Caixa de som estilo Alexa (anel LED) | `pulso` |
| incensario.glb | Incensário de latão com varetas | `fumaca` |
| fonte_agua.glb | Fonte de 2 níveis | `fluxo` |
| almofadas_encosto.glb | 3 almofadas de encosto | — |

As animações são clipes glTF em loop (use `AnimationMixer.clipAction(...).play()`).

## Observação
Dos itens pedidos, o banco Wi-Fi foi usado para compor os 5 do pátio (conjunto + 4 módulos); os outros 5 itens ficaram na sala restaurativa.
