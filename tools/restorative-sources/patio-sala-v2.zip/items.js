import * as THREE from 'three';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';

const M = (color, o = {}) => new THREE.MeshStandardMaterial({color, roughness: .7, metalness: 0, ...o});
export const PAL = {
  blue: 0x1f86d1, blueDark: 0x15629c, blueLight: 0x4aa8ec,
  steel: 0x2a3a45, brass: 0xc9973f, brassDark: 0x8d6a24,
  stone: 0x5d6b73, stoneDark: 0x44505a, water: 0x58d0e6,
  fabric: 0x23262b, led: 0x45e6ff, wood: 0x7a5233, ember: 0xff7a2e,
  mustard: 0xe0a93a, coral: 0xe2674f, teal: 0x2e9c93, cream: 0xf0e4cc, indigo: 0x2c3a78
};

function mesh(geo, mat, name, pos, cast = true) {
  const m = new THREE.Mesh(geo, mat);
  m.name = name; if (pos) m.position.set(...pos);
  m.castShadow = cast; m.receiveShadow = true; return m;
}
function empty(name, pos, ry = 0) {
  const o = new THREE.Object3D(); o.name = name; o.position.set(...pos); o.rotation.y = ry; return o;
}

/* ---------- Pátio: banco Wi-Fi (arcos modulares, azul) ---------- */
function sector(rIn, rOut, a0, a1) {
  const s = new THREE.Shape();
  s.absarc(0, 0, rOut, a0, a1, false);
  s.absarc(0, 0, rIn, a1, a0, true);
  s.closePath(); return s;
}
function extr(shape, h, cs = 16) {
  const g = new THREE.ExtrudeGeometry(shape, {depth: h, bevelEnabled: true, bevelSize: .025, bevelThickness: .025, bevelSegments: 2, curveSegments: cs});
  g.rotateX(-Math.PI / 2); return g;
}
const SPAN = Math.PI / 2; // 90°
const A0 = Math.PI / 2 - SPAN / 2, A1 = Math.PI / 2 + SPAN / 2;

function arcBench(name, rIn, rOut, seats, mat) {
  const g = new THREE.Group(); g.name = name;
  const steel = M(0x9aa8b3, {metalness: .3, roughness: .45});
  const fabric = M(PAL.blue, {roughness: .88});
  const fabricLight = M(PAL.blueLight, {roughness: .9});
  const frameM = M(PAL.blueDark, {roughness: .5});
  const glow = new THREE.MeshStandardMaterial({color: PAL.led, emissive: PAL.led, emissiveIntensity: 1.6, roughness: .3});
  const btn = M(PAL.blueDark, {roughness: .6});
  const rb = rOut - .22, rm = (rIn + rb) / 2;
  const seg = SPAN / seats, gap = .012;
  // estrutura contínua sob o estofado
  g.add(mesh(extr(sector(rIn + .03, rOut - .03, A0 + .02, A1 - .02), .09), frameM, name + '_estrutura', [0, .2, 0]));
  // faixa de luz embaixo (efeito sinal)
  g.add(mesh(extr(sector(rIn + .06, rIn + .085, A0 + .06, A1 - .06), .012), glow, name + '_led', [0, .185, 0], false));
  // pernas metálicas
  const legs = seats <= 3 ? 3 : 5;
  for (let i = 0; i < legs; i++) {
    const a = A0 + SPAN * (.04 + .92 * i / (legs - 1));
    for (const r of [rIn + .14, rOut - .14]) {
      const leg = mesh(new THREE.CylinderGeometry(.026, .018, .21, 12), steel, `${name}_perna_${i}_${r > rm ? 'e' : 'i'}`, [r * Math.cos(a), .105, -r * Math.sin(a)]);
      g.add(leg);
    }
  }
  // assentos e encostos segmentados (estofado capitonê)
  for (let i = 0; i < seats; i++) {
    const a0 = A0 + i * seg + gap, a1 = A0 + (i + 1) * seg - gap, am = (a0 + a1) / 2;
    g.add(mesh(extr(sector(rIn + .05, rb - .02, a0, a1), .13, 5), fabricLight, `${name}_assento_${i + 1}`, [0, .29, 0]));
    g.add(mesh(extr(sector(rb, rOut - .02, a0, a1), .5, 5), fabric, `${name}_encosto_${i + 1}`, [0, .38, 0]));
    // botões do capitonê
    for (const [r, y] of [[rb - .005, .78], [rb - .005, .6]]) {
      g.add(mesh(new THREE.SphereGeometry(.016, 10, 8), btn, `${name}_botao_${i + 1}_${y}`, [r * Math.cos(am), y, -r * Math.sin(am)], false));
    }
    g.add(empty(`SIT_${name}_${i + 1}`, [rm * Math.cos(am), .46, -rm * Math.sin(am)], Math.atan2(-rm * Math.cos(am), rm * Math.sin(am))));
  }
  // acabamento superior em aço escovado
  g.add(mesh(extr(sector(rb - .01, rOut, A0, A1), .035), steel, name + '_topo', [0, .89, 0]));
  return g;
}
const bluePaint = () => M(PAL.blue, {roughness: .45, metalness: .05});


export function bancoArcoExterno() { return arcBench('arco_externo', 2.9, 3.5, 8, bluePaint()); }
export function bancoArcoMedio() { return arcBench('arco_medio', 1.95, 2.55, 5, bluePaint()); }
export function bancoArcoInterno() { return arcBench('arco_interno', 1.0, 1.6, 3, bluePaint()); }
export function bancoPontoCentral() {
  const g = new THREE.Group(); g.name = 'ponto_central';
  const steel = M(0x9aa8b3, {metalness: .3, roughness: .45});
  const glow = new THREE.MeshStandardMaterial({color: PAL.led, emissive: PAL.led, emissiveIntensity: 1.8, roughness: .25});
  g.add(mesh(new THREE.CylinderGeometry(.34, .38, .05, 48), steel, 'base', [0, .025, 0]));
  g.add(mesh(new THREE.CylinderGeometry(.1, .14, .38, 32), M(PAL.blueDark, {roughness: .5}), 'coluna', [0, .24, 0]));
  g.add(mesh(new THREE.CylinderGeometry(.46, .42, .06, 56), bluePaint(), 'tampo', [0, .46, 0]));
  g.add(mesh(new THREE.TorusGeometry(.445, .012, 8, 64), glow, 'led_borda', [0, .492, 0], false)).children.at(-1).rotation.x = Math.PI / 2;
  g.add(mesh(new THREE.CylinderGeometry(.34, .34, .008, 48), M(PAL.blueLight, {roughness: .18, metalness: .15}), 'inlay', [0, .494, 0]));
  // "ponto" do Wi-Fi em cúpula luminosa
  g.add(mesh(new THREE.SphereGeometry(.1, 28, 16, 0, Math.PI * 2, 0, Math.PI / 2), glow, 'ponto_wifi', [0, .498, 0], false));
  return g;
}

export function bancoWifiCompleto() {
  const g = new THREE.Group(); g.name = 'banco_wifi_completo';
  g.add(bancoArcoExterno(), bancoArcoMedio(), bancoArcoInterno(), bancoPontoCentral());
  return g;
}

/* ---------- Sala restaurativa ---------- */
function rugTexture() {
  const W = 1536, H = 1080, hw = W / 2, hh = H / 2;
  const q = document.createElement('canvas'); q.width = hw; q.height = hh; const x = q.getContext('2d');
  const C = {base: '#27346b', red: '#b8402f', red2: '#d4614a', gold: '#e0a93a', cream: '#f0e4cc', teal: '#2e9c93', dark: '#161d45'};
  const fillFrom = (inset, color) => { x.fillStyle = color; x.fillRect(inset, inset, hw, hh); };
  fillFrom(0, C.dark); fillFrom(22, C.gold); fillFrom(30, C.dark); fillFrom(40, C.red); fillFrom(152, C.cream); fillFrom(158, C.dark); fillFrom(168, C.base);
  // treliça do campo
  x.save(); x.beginPath(); x.rect(168, 168, hw, hh); x.clip();
  x.strokeStyle = 'rgba(240,228,204,.11)'; x.lineWidth = 2;
  for (let d = -hh; d < hw + hh; d += 54) { x.beginPath(); x.moveTo(d, 0); x.lineTo(d + hh, hh); x.stroke(); x.beginPath(); x.moveTo(d, hh); x.lineTo(d + hh, 0); x.stroke(); }
  x.restore();
  const flower = (cx, cy, r, petal, mid) => {
    x.save(); x.translate(cx, cy);
    x.fillStyle = petal; for (let i = 0; i < 8; i++) { x.save(); x.rotate(i * Math.PI / 4); x.beginPath(); x.ellipse(0, -r * .62, r * .26, r * .46, 0, 0, 7); x.fill(); x.restore(); }
    x.fillStyle = C.dark; x.beginPath(); x.arc(0, 0, r * .36, 0, 7); x.fill();
    x.fillStyle = mid; x.beginPath(); x.arc(0, 0, r * .24, 0, 7); x.fill();
    x.fillStyle = C.red; x.beginPath(); x.arc(0, 0, r * .1, 0, 7); x.fill(); x.restore();
  };
  const diamond = (cx, cy, r, f) => { x.fillStyle = f; x.beginPath(); x.moveTo(cx, cy - r); x.lineTo(cx + r * .7, cy); x.lineTo(cx, cy + r); x.lineTo(cx - r * .7, cy); x.closePath(); x.fill(); };
  // faixa vermelha: flores e losangos
  const cb = 96;
  for (let k = 0; k < 8; k++) { const px = hw - 48 - k * 96; if (px > 150) { flower(px, cb, 38, C.cream, C.gold); diamond(px - 48, cb, 14, C.dark); } }
  for (let k = 0; k < 5; k++) { const py = hh - 48 - k * 96; if (py > 150) { flower(cb, py, 38, C.cream, C.gold); diamond(cb, py - 48, 14, C.dark); } }
  flower(cb, cb, 58, C.gold, C.cream);
  // cantoneiras do campo
  x.save(); x.beginPath(); x.rect(168, 168, hw, hh); x.clip();
  [[250, C.dark], [238, C.cream], [222, C.red], [190, C.dark], [178, C.teal]].forEach(([r, c]) => { x.fillStyle = c; x.beginPath(); x.moveTo(168, 168); x.arc(168, 168, r, 0, Math.PI / 2); x.closePath(); x.fill(); });
  for (let i = 0; i < 7; i++) { const a = i * (Math.PI / 2) / 6; diamond(168 + 214 * Math.cos(a), 168 + 214 * Math.sin(a), 11, C.cream); }
  flower(168 + 70, 168 + 70, 40, C.gold, C.cream);
  x.restore();
  // medalhão central
  x.save(); x.beginPath(); x.rect(168, 168, hw, hh); x.clip(); x.translate(hw, hh); x.scale(1, .7);
  [[430, C.dark], [414, C.cream], [394, C.teal], [360, C.dark], [348, C.red]].forEach(([r, c]) => { x.fillStyle = c; x.beginPath(); x.arc(0, 0, r, 0, 7); x.fill(); });
  const star = (n, r1, r2, c) => { x.fillStyle = c; x.beginPath(); for (let i = 0; i < n * 2; i++) { const r = i % 2 ? r2 : r1, a = i * Math.PI / n - Math.PI / 2; x.lineTo(r * Math.cos(a), r * Math.sin(a)); } x.closePath(); x.fill(); };
  star(16, 330, 215, C.gold); star(16, 290, 200, C.dark); star(8, 230, 130, C.cream); star(8, 190, 110, C.teal);
  for (let i = 0; i < 16; i++) { const a = i * Math.PI / 8 + Math.PI / 16; x.fillStyle = C.cream; x.beginPath(); x.arc(270 * Math.cos(a), 270 * Math.sin(a), 8, 0, 7); x.fill(); }
  x.fillStyle = C.dark; x.beginPath(); x.arc(0, 0, 86, 0, 7); x.fill();
  x.fillStyle = C.gold; x.beginPath(); x.arc(0, 0, 70, 0, 7); x.fill();
  for (let i = 0; i < 8; i++) { x.save(); x.rotate(i * Math.PI / 4); x.fillStyle = C.red; x.beginPath(); x.ellipse(0, -38, 14, 26, 0, 0, 7); x.fill(); x.restore(); }
  x.fillStyle = C.dark; x.beginPath(); x.arc(0, 0, 20, 0, 7); x.fill();
  x.restore();
  // espelha para as 4 partes
  const c = document.createElement('canvas'); c.width = W; c.height = H; const t = c.getContext('2d');
  t.drawImage(q, 0, 0);
  t.save(); t.translate(W, 0); t.scale(-1, 1); t.drawImage(q, 0, 0); t.restore();
  t.save(); t.translate(0, H); t.scale(1, -1); t.drawImage(q, 0, 0); t.restore();
  t.save(); t.translate(W, H); t.scale(-1, -1); t.drawImage(q, 0, 0); t.restore();
  // trama de lã
  t.fillStyle = 'rgba(0,0,0,.06)'; for (let y = 0; y < H; y += 3) t.fillRect(0, y, W, 1);
  t.fillStyle = 'rgba(255,255,255,.03)'; for (let xx = 0; xx < W; xx += 3) t.fillRect(xx, 0, 1, H);
  const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 8; return tex;
}
export function tapeteIndiano() {
  const g = new THREE.Group(); g.name = 'tapete_indiano';
  const tex = rugTexture(), edge = M(PAL.indigo, {roughness: 1});
  g.add(mesh(new RoundedBoxGeometry(2.2, .035, 1.55, 3, .014), [edge, edge, new THREE.MeshStandardMaterial({map: tex, roughness: .96}), edge, edge, edge], 'tapete', [0, .0175, 0], false));
  // franjas em tufos, mescladas em uma única malha
  const parts = [];
  for (let s of [-1, 1]) for (let i = 0; i < 46; i++) {
    const b = new THREE.BoxGeometry(.11, .006, .018);
    b.rotateY((i % 2 ? 1 : -1) * .1 + (i % 3 - 1) * .03);
    b.translate(s * (1.1 + .052), .004, -.765 + i * (1.53 / 45)); parts.push(b);
  }
  g.add(mesh(mergeGeometries(parts), M(PAL.cream, {roughness: 1}), 'franjas', null, false));
  g.add(empty('SIT_tapete_1', [0, .035, 0], 0));
  return g;
}

export function caixaDeSom() {
  const g = new THREE.Group(); g.name = 'caixa_de_som';
  const body = mesh(new THREE.CylinderGeometry(.085, .09, .22, 40), M(PAL.fabric, {roughness: .95}), 'corpo', [0, .12, 0]);
  const base = mesh(new THREE.CylinderGeometry(.092, .092, .02, 40), M(0x111418, {roughness: .6}), 'base', [0, .01, 0]);
  const top = mesh(new THREE.CylinderGeometry(.086, .086, .012, 40), M(0x15181c, {roughness: .5}), 'tampo', [0, .236, 0]);
  const led = mesh(new THREE.TorusGeometry(.078, .005, 8, 48), new THREE.MeshStandardMaterial({color: PAL.led, emissive: PAL.led, emissiveIntensity: 1.6, roughness: .3}), 'led_anel', [0, .243, 0], false);
  led.rotation.x = Math.PI / 2;
  g.add(base, body, top, led);
  for (let i = 0; i < 4; i++) {
    const a = i * Math.PI / 2 + Math.PI / 4;
    g.add(mesh(new THREE.CylinderGeometry(.007, .007, .004, 12), M(0x888e96, {metalness: .5, roughness: .4}), 'botao_' + i, [.045 * Math.cos(a), .243, .045 * Math.sin(a)], false));
  }
  g.add(mesh(new THREE.CylinderGeometry(.007, .007, .004, 12), new THREE.MeshStandardMaterial({color: 0xff4a4a, emissive: 0xff4a4a, emissiveIntensity: .8}), 'led_mic', [0, .243, 0], false));
  const pulse = new THREE.AnimationClip('pulso', 2, [
    new THREE.VectorKeyframeTrack('led_anel.scale', [0, 1, 2], [1, 1, 1, 1.12, 1.12, 1.12, 1, 1, 1])
  ]);
  g.userData.clips = [pulse];
  return g;
}

export function incensario() {
  const g = new THREE.Group(); g.name = 'incensario';
  const brass = M(PAL.brass, {metalness: .85, roughness: .35});
  const dark = M(PAL.brassDark, {metalness: .8, roughness: .45});
  g.add(mesh(new THREE.CylinderGeometry(.09, .1, .02, 32), dark, 'base', [0, .01, 0]));
  for (let i = 0; i < 3; i++) {
    const a = i * 2 * Math.PI / 3; const l = mesh(new THREE.CylinderGeometry(.012, .008, .07, 8), brass, 'perna_' + i, [.06 * Math.cos(a), .055, .06 * Math.sin(a)]); g.add(l);
  }
  const bowl = mesh(new THREE.SphereGeometry(.1, 32, 20, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2), brass, 'tigela', [0, .15, 0]); bowl.material.side = THREE.DoubleSide; g.add(bowl);
  g.add(mesh(new THREE.TorusGeometry(.1, .008, 10, 40), brass, 'borda', [0, .15, 0])).children.at(-1).rotation.x = Math.PI / 2;
  g.add(mesh(new THREE.CylinderGeometry(.092, .092, .006, 32), M(0x2a2420, {roughness: 1}), 'cinzas', [0, .135, 0], false));
  // varetas
  const stickM = M(0x6b4b2a, {roughness: .9});
  for (let i = 0; i < 3; i++) {
    const s = mesh(new THREE.CylinderGeometry(.0025, .0025, .26, 6), stickM, 'vareta_' + i, [0, .27, 0]);
    s.rotation.z = (i - 1) * .22; s.rotation.x = (i % 2 ? .12 : -.1); s.position.set((i - 1) * .02, .26, (i - 1) * .012); g.add(s);
    g.add(mesh(new THREE.SphereGeometry(.006, 8, 8), new THREE.MeshStandardMaterial({color: PAL.ember, emissive: PAL.ember, emissiveIntensity: 2}), 'brasa_' + i, [s.position.x + Math.sin(-s.rotation.z) * .13, .26 + Math.cos(s.rotation.z) * .13, s.position.z], false));
  }
  // fumaça animada
  const tracks = [];
  for (let i = 0; i < 5; i++) {
    const sm = mesh(new THREE.SphereGeometry(.022, 10, 10), new THREE.MeshStandardMaterial({color: 0xdfe6ea, roughness: 1, transparent: true, opacity: .45}), 'fumaca_' + i, [0, .4, 0], false);
    g.add(sm);
    const t0 = i * .6, T = 3, ky = [0, 1, 2, 3].map(k => (t0 + k * T / 3) % T).sort((a, b) => a - b);
    const times = [0, .75, 1.5, 2.25, 3];
    const off = i * .6; const pos = [], scl = [];
    for (const t of times) { const u = ((t + off) % T) / T; pos.push(.014 * Math.sin(u * 9 + i), .4 + u * .35, .014 * Math.cos(u * 7 + i)); const s = Math.max(.01, Math.sin(Math.PI * u)) * (1 + u * 2.2); scl.push(s, s, s); }
    tracks.push(new THREE.VectorKeyframeTrack(`fumaca_${i}.position`, times, pos), new THREE.VectorKeyframeTrack(`fumaca_${i}.scale`, times, scl));
  }
  g.userData.clips = [new THREE.AnimationClip('fumaca', 3, tracks)];
  return g;
}

function stoneTexture() {
  const c = document.createElement('canvas'); c.width = c.height = 256; const x = c.getContext('2d');
  x.fillStyle = '#6a7880'; x.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 1800; i++) { const v = 90 + Math.random() * 60 | 0; x.fillStyle = `rgba(${v},${v + 8},${v + 12},.35)`; x.fillRect(Math.random() * 256, Math.random() * 256, 1 + Math.random() * 3, 1 + Math.random() * 3); }
  for (let i = 0; i < 260; i++) { x.fillStyle = 'rgba(70,110,80,.16)'; x.beginPath(); x.arc(Math.random() * 256, Math.random() * 256, 1 + Math.random() * 4, 0, 7); x.fill(); }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.wrapS = t.wrapT = THREE.RepeatWrapping; return t;
}
export function fonteAgua() {
  const g = new THREE.Group(); g.name = 'fonte_agua';
  const st = new THREE.MeshStandardMaterial({map: stoneTexture(), roughness: .85}); st.side = THREE.DoubleSide;
  const stD = new THREE.MeshStandardMaterial({color: 0x4a5860, roughness: .9});
  const water = new THREE.MeshStandardMaterial({color: PAL.water, emissive: 0x0e6a80, emissiveIntensity: .6, roughness: .06, metalness: .1, transparent: true, opacity: .8});
  const stream = new THREE.MeshStandardMaterial({color: 0xbdf1ff, emissive: 0x4fd0ea, emissiveIntensity: .5, roughness: .1, transparent: true, opacity: .55});
  const lathe = (pts, name, mat = st) => { const m = mesh(new THREE.LatheGeometry(pts.map(([r, y]) => new THREE.Vector2(r, y)), 56), mat, name, [0, 0, 0]); return m; };
  // bacia principal, coluna, bacia intermediária e bacia superior (perfis torneados)
  g.add(lathe([[0, 0], [.72, 0], [.76, .04], [.76, .28], [.80, .32], [.80, .42], [.76, .46], [.68, .46], [.68, .30], [0, .30]], 'bacia'));
  g.add(lathe([[0, .30], [.18, .30], [.18, .36], [.10, .46], [.075, .56], [.075, .78], [.11, .82], [0, .82]], 'coluna'));
  g.add(lathe([[0, .80], [.12, .80], [.2, .84], [.38, .93], [.42, .99], [.42, 1.03], [.38, 1.05], [.35, 1.02], [.31, .98], [0, .98]], 'bacia_media'));
  g.add(mesh(new THREE.CylinderGeometry(.05, .06, .24, 20), st, 'haste', [0, 1.09, 0]));
  g.add(lathe([[0, 1.18], [.08, 1.18], [.12, 1.21], [.22, 1.26], [.25, 1.30], [.22, 1.31], [.19, 1.29], [.15, 1.27], [0, 1.27]], 'bacia_alta'));
  // águas
  g.add(mesh(new THREE.CylinderGeometry(.67, .67, .02, 56), water, 'agua', [0, .40, 0], false));
  g.add(mesh(new THREE.CylinderGeometry(.33, .33, .02, 40), water, 'agua_media', [0, 1.0, 0], false));
  g.add(mesh(new THREE.CylinderGeometry(.17, .17, .02, 32), water, 'agua_alta', [0, 1.285, 0], false));
  g.add(mesh(new THREE.CylinderGeometry(.012, .02, .24, 10), stream, 'jato', [0, 1.4, 0], false));
  g.add(mesh(new THREE.SphereGeometry(.026, 10, 10), stream, 'jato_topo', [0, 1.53, 0], false));
  // luzes subaquáticas
  const led = new THREE.MeshStandardMaterial({color: PAL.led, emissive: PAL.led, emissiveIntensity: 2});
  for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2 + Math.PI / 4; g.add(mesh(new THREE.SphereGeometry(.03, 10, 8), led, 'luz_' + i, [.5 * Math.cos(a), .33, .5 * Math.sin(a)], false)); }
  // fios de água escorrendo (bacia alta -> média, média -> principal)
  const sheet = (n, r1, y1, r2, y2, count) => { for (let i = 0; i < count; i++) { const a = i * 2 * Math.PI / count, h = y1 - y2, rm = (r1 + r2) / 2; const s = mesh(new THREE.BoxGeometry(.016, h, .005), stream, `${n}_${i}`, [rm * Math.cos(a), (y1 + y2) / 2, rm * Math.sin(a)], false); s.rotation.y = -a + Math.PI / 2; s.rotation.x = Math.atan2(r2 - r1, h) * 0; g.add(s); } };
  sheet('fio_alto', .26, 1.29, .29, 1.0, 12); sheet('fio_medio', .44, 1.03, .52, .41, 16);
  // animações
  const tracks = [];
  const ring = (n, y, base, off, smax, T) => {
    const r = mesh(new THREE.TorusGeometry(base, .006, 6, 48), new THREE.MeshStandardMaterial({color: 0xcff6ff, emissive: 0x6fdcf0, emissiveIntensity: .6, transparent: true, opacity: .8}), n, [0, y, 0], false);
    r.rotation.x = Math.PI / 2; g.add(r);
    const ts = [0, .25, .5, .75, 1].map(u => u * T), sc = []; ts.forEach(t => { const u = ((t + off) % T) / T, s = .25 + u * smax; sc.push(s, s, s); });
    tracks.push(new THREE.VectorKeyframeTrack(n + '.scale', ts, sc));
  };
  ring('ripple_a', .412, .2, 0, 2.9, 2.4); ring('ripple_b', .412, .2, .8, 2.9, 2.4); ring('ripple_c', .412, .2, 1.6, 2.9, 2.4);
  ring('ripple_m1', 1.012, .12, 0, 2.2, 1.8); ring('ripple_m2', 1.012, .12, .9, 2.2, 1.8);
  for (let i = 0; i < 8; i++) {
    const a = i * Math.PI / 4 + .2; g.add(mesh(new THREE.SphereGeometry(.014, 8, 8), stream, 'gota_' + i, [.5 * Math.cos(a), 1.0, .5 * Math.sin(a)], false));
    const T = 1.2, ts = [0, .3, .6, .9, 1.2], off = i * .15, pp = [];
    ts.forEach(t => { const u = ((t + off) % T) / T; pp.push((.44 + u * .1) * Math.cos(a), 1.02 - u * .6, (.44 + u * .1) * Math.sin(a)); });
    tracks.push(new THREE.VectorKeyframeTrack(`gota_${i}.position`, ts, pp));
  }
  tracks.push(new THREE.VectorKeyframeTrack('jato.scale', [0, .6, 1.2, 2.4], [1, 1, 1, 1, 1.2, 1, 1, 1, 1, 1, 1, 1]));
  tracks.push(new THREE.VectorKeyframeTrack('jato_topo.position', [0, .6, 1.2, 2.4], [0, 1.53, 0, 0, 1.58, 0, 0, 1.53, 0, 0, 1.53, 0]));
  g.userData.clips = [new THREE.AnimationClip('fluxo', 2.4, tracks)];
  return g;
}


export function almofadasEncosto() {
  const g = new THREE.Group(); g.name = 'almofadas_encosto';
  const defs = [[PAL.mustard, -.5, .06], [PAL.coral, 0, -.04], [PAL.teal, .5, .08]];
  const trim = M(PAL.cream, {roughness: .9});
  defs.forEach(([c, x, tilt], i) => {
    const grp = new THREE.Group(); grp.name = 'almofada_' + (i + 1);
    const body = mesh(new RoundedBoxGeometry(.46, .46, .13, 4, .055), M(c, {roughness: .95}), 'corpo', [0, 0, 0]);
    grp.add(body);
    grp.add(mesh(new THREE.TorusGeometry(.12, .008, 6, 32), trim, 'bordado', [0, 0, .066], false));
    grp.add(mesh(new THREE.SphereGeometry(.018, 10, 10), trim, 'botao', [0, 0, .068], false));
    for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4; grp.add(mesh(new THREE.SphereGeometry(.009, 6, 6), trim, 'ponto_' + k, [.19 * Math.cos(a) * .9, .19 * Math.sin(a) * .9, .067], false)); }
    grp.position.set(x, .26, -.01 * i); grp.rotation.set(-.22, tilt, 0);
    g.add(grp);
  });
  return g;
}

export const CATALOG = {
  patio: [
    ['banco_wifi_completo', 'Banco Wi-Fi (conjunto completo)', bancoWifiCompleto],
    ['banco_arco_externo', 'Banco Wi-Fi · arco externo', bancoArcoExterno],
    ['banco_arco_medio', 'Banco Wi-Fi · arco médio', bancoArcoMedio],
    ['banco_arco_interno', 'Banco Wi-Fi · arco interno', bancoArcoInterno],
    ['banco_ponto_central', 'Banco Wi-Fi · ponto central', bancoPontoCentral]
  ],
  sala_restaurativa: [
    ['tapete_indiano', 'Tapete indiano estilizado', tapeteIndiano],
    ['caixa_de_som', 'Caixa de som inteligente', caixaDeSom],
    ['incensario', 'Incensário', incensario],
    ['fonte_agua', 'Fonte de água animada', fonteAgua],
    ['almofadas_encosto', 'Almofadas de encosto', almofadasEncosto]
  ]
};
